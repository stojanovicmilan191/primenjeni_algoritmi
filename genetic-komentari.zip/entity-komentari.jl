mutable struct Entity
    genes::Array{Int64, 1}
    fitness::Int64
end

function generateEntity(genesLength)
    return Entity(rand(0:1, genesLength), 0) #funkcija rand daje decimalni broj od 0 do 1 ali kompajler automatski zaokruzuje broj na 0 ili 1 jer je niz intova
end

function printEntity(entity1)
    for i in 1:length(entity1.genes)
        print(entity1.genes[i])
    end
    print(" $(entity1.fitness) \n")
end

function crossover!(entity1, entity2, crossoverPoint)
    for i in 1:crossoverPoint
        x = entity1.genes[i]
        entity1.genes[i] = entity2.genes[i]
        entity2.genes[i] = x
    end
end

function mutate!(entity1, mutationPercentage)
    if rand(Float64) < mutationPercentage
        mutationPoint = rand(1:length(entity1.genes))
        entity1.genes[mutationPoint] = 1 - entity1.genes[mutationPoint]
    end
end