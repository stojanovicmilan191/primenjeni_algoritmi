include("geneticAlgorithm.jl")
genesLength = 20
populationSize = 20
fitValue = 19
crossoverPoint = 3
mutationPercentage = 0.2
selectionSize = 5
repeatSize = 3
totalRepeatSize = 300

population = generatePopulation(populationSize, genesLength)
calculatePopulationFitness!(population, fitValue)
printPopulation(population)
popGen, population = geneticAlgorithm!(population, fitValue, selectionSize, crossoverPoint, mutationPercentage, repeatSize, totalRepeatSize)
print("Populacija:\n")
printPopulation(population)
print("Ukupan broj generacija je $popGen \n")
print("Najbolji fitnes: ", population[1].fitness)