include("entity.jl")

function generatePopulation(n, genesLength)
    data = []
    for i in 1:n
        entity1 = generateEntity(genesLength)
        push(data, entity1)
    end
    return data
end

function printPopulation(data)
    for i in 1:length(data)
        printEntity(data[i])
    end
end

function calculatePopulationFitness(data, fitValue)
    for i in 1:length(data)
        calculateFitness!(data[i], fitValue)
    end
    sort!(data, by = d->d.fitness, rev = flase);
end

function crossoverPopulation(data, crossoverPoint)
    newData = []
    for i in 1:length(data)
        for j in 1:length(data)
            entity1 = deepcopy(data[i])
            entity2 = deepcopy(data[j])
            crossover!(entity1, entity2, crossoverPoint)
            push!(newData, entity1)
            push!(newData, entity2)
            # imamo n iteracija po i, n iteracija po j za svako i sto znaci da ce ukupan broj jedinki u novoj generaciji biti n*n
        end
    end
end

function mutatePopulation!(data, mutationPercentage)
    for i in 1:length(data)
        mutate!(data[i], mutationPercentage)
    end
end

function selectPopulation(data, n)
    return deepcopy(data[1:n]) # Kako smo imali n*n broj jedinki bitno je izdvojiti samo n iz populacije kako bi odrzali konstantan broj jednki u svakoj generaciji 
end