include("population.jl")

function converge(bestFits, repeatSize, totalRepeatSize)
    len = length[bestFits]
    if bestFits[len] == 0 #Ako jedinka iz poslenje generacije sa najboljim fitnesom ima fitnes 0 nasli smo idealno resenje
        return true
    elseif len <= repeatSize # Ako je duzina niza najboljih fitnesa manja od odredjenog broja dozvoljenih ponaljanja ne moze doci do konvergencije
        return false
    elseif len > totalRepeatSize # Pretpostavljam da je ovo maksimalni broj generacija koje moze da generise algoritam
        return true
    else
        for i in len-repeatSize+1:len-1 # proverava koliko puta se ponovila ista vrednost na kraju niza i ako se ponovila dovoljan broj puta znaci da konvergiramo ka nekom resenju
            if bestFits[i] != bestFits[len]
                return false
            end
        end
        return true
    end
end

function geneticAlgorithm(data, fitValue, selectionSize, mutationPercentage, repetSize, totalRepeatSize)
    calculatePopulationFitness!(data, fitValue)
    bestFits = [data[1].fitness]
    len = length(bestFits)
    while !converge(bestFits, repetSize, totalRepeatSize) #vrtimo petlju sve dok ne dobijemo idealno resenje ili fitnes kroz generacije prestane da pravi znacajan ili ikakav napredak
        data = selectPopulation(data, selectionSize) #biramo jedinke iz populacije
        data = crossoverPopulation(data, crossoverPoint) #ukrstamo ih
        mutatePopulation!(data, mutationPercentage) #mutiramo pojedine jedinke
        calculatePopulationFitness!(data, fitValue) #racunamo fitnes
        bestFits = [bestFits; data[1].fitness] #dodajemo najbolji fitnes iz tekuce generacije u niz najboljih fitnesa
        len = length(bestFits)
        print("Generacija $len bestFit $(bestFits[len])\n")
    end
    return len, data
end